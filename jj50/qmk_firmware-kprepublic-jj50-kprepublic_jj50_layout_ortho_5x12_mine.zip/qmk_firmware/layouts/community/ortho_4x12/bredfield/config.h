#pragma once

#define TAPPING_TERM 200
#define PERMISSIVE_HOLD